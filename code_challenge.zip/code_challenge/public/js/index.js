
/* The function below allows to find Products accordingly to the choice of the Customer.*/

function getProducts(customer_id){
    $.ajax({
        type: "POST",
        url: "../model/filter.php",
        data:'customer_id='+customer_id,
        success: function(data){
            $("#product").html(data);
            $("#price").html("<option value=\"\">Waiting for the Product</option>");
            $('#boxResults').hide()
        }
    });
}

/* The function below allows to find Prices accordingly to the choice of the Customer and the Product.*/

function getPrices(customer_id, product_id){
    $('#boxResults').show()
    $.ajax({
        type: "POST",
        url: "../model/filter.php?p="+product_id,
        data:'customer_id='+customer_id,
        success: function(data){
            data = data.split("----------");
            $("#price").html(data[0]);

            if(data[2] == "success")
            {
                $("#boxResults").html(data[1]);
            }
            else
            {    
                $('#boxResults').hide()
            }
        }
    });
}


/* The function below allows to show filtered results in a table appearing just below the filters.*/

function getResults(customer_id, product_id, price_id){
    product_name = $('#product option:selected').text();
    customer_name = $('#customer option:selected').text();
    product_price = $('#price option:selected').text();
    $('#boxResults').show()
    $.ajax({
            type: "POST",
            url: "../model/filter.php?p="+product_id+"&m="+price_id+"&pn="+product_name+"&c="+customer_name+"&mo="+product_price,
            data:'customer_id='+customer_id,
            success: function(data){
                $("#boxResults").html(data);
            }
        });
}