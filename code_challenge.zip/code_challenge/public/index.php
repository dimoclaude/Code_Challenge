<?php 
  /**
   * Index page of the Project
   */

  /**
   * Page header inclusion. Such a file contains Meta, CSS, Icon, etc
   */
  require_once("./inclusions/header.php");


  /**
   * Filter class inclusion. In this file, you will find the Class I have create to manage filters
   */
  require_once("../app/Filter.php");

  /**
   * Database and App classes inclusion. Here are the classes to access the database and send request to the server. 
   */
  require("../app/Tables/Database.php");
  require("../app/Tables/App.php");

  /**
   * Page main content inclusion. Here is the main content of the index Page. 
   */
  require_once("./inclusions/page_vew.php");

  /**
   * Page footer inclusion. Such a file includes the footer and some JS files, as the JQuery library
   */
  require_once("./inclusions/footer.php");
?>
