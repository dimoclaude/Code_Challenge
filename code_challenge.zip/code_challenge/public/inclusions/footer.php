        <!-- Footer -->
        <footer>
          <div class="pull-right">
          </div>
          <div class="clearfix"></div>
        </footer>
        <!-- /Footer -->
        
      </div>
    </div>
        

    <!-- jQuery -->
    <script src="./js/jquery.min.js"></script>
   
    <!-- Index Scripts -->
    <script src="./js/index.js"></script>
  </body>
</html>
<!-- /Body-->
