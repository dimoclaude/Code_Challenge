<!-- page content -->
<div class="right_col" role="main">
	<div class="">
		<div class="col-sm-12 col-md-12" style="margin-top:30px">
			<div class="title_left">
				<h1 class="main_text_second_stu my-3 font-weight-bold"> Filters for Customer, Product, and Price</h1>
      </div>
    </div>
  </div>
  <div class="clearfix"></div>

    <!-- Home image: This is a free image that I found on pixabay.com. The image is freely accessible via the link: https://pixabay.com/fr/photos/une-biblioth%C3%A8que-livres-globe-1668174/-->
    <div class="col-md-12 col-sm-12  ">
      <div class="x_panel">
          <img src="./img/book_shop.jpg" alt="dd" style="height:auto; max-height:100%; max-width:100%">
      </div>
    </div>
    <!-- /Home image-->


    <!-- Filters-->
    <div class="col-md-12 col-sm-12  ">
      <div class="x_panel">
        <div class="">
          <h3 class="main_text_second_stu font-weight-bold"><i class="fa fa-filter main_fa_stu"></i> My Filters</h3>
          <div class="clearfix"></div>
        </div>
        <div class="">
          <form class="form-horizontal form-label-left" id="AjoutMatiere">
    				<div class="form-group row">

              <?php

                /*
                  *Instantiation of all Filters 
                */ 
                $filters = new Filter();

                /*
                  * Collect customer data from the database 
                */ 
                $data = ['all_customers' => 'All the Customers', 'no_customer' => 'No Customer'];
                $statement = "SELECT customer_id, customer_name FROM customers ORDER BY customer_name ASC";

                foreach(App\App::getDB() -> SELECT($statement) AS $customer)
                {
                  $data[$customer -> customer_id] = $customer -> customer_name;
                }      

                /*
                  *Print the customer list 
                */ 
                echo $filters -> select($data, 'customer');

                /*
                  * Change the text of the first option the product list 
                */ 
                $filters -> getOptionTitle("Waiting for a");

                /*
                  * Change the length of the product list 
                */ 
                $filters -> getOptionLength(6);

                /*
                  * Use of the html event corresponding to the product list 
                */ 
                $filters -> getOnChangeEvent("getPrices($('#customer').val(), this.value)");

                /*
                  *Print the product list with respect to the selected Customer
                */ 
                echo $filters -> select(array(), 'product');

                /*
                  * Change the length of the price list 
                */ 
                $filters -> getOptionLength(3);

                /*
                  * Use of the html event corresponding to the price list 
                */ 
                $filters -> getOnChangeEvent("getResults($('#customer').val(), $('#product').val(), this.value)");

                /*
                  *Print the price list with respect to the selected Customer and Product
                */ 
                echo $filters -> select(array(), 'price');

              ?>

              <!-- In this Project, the HTML events are managed by JQuery, explaining why there is no submit button-->
		  	  	</div>
	  		  </form>
        </div>
      </div>
    </div>
    <!-- /Filters-->


    <!-- Results: They are showed in tables that are contained in the div having the id = boxResults -->
    <div class="col-md-12 col-sm-12  ">
      <div class="x_panel">
        <div class="">
          <h3 class="main_text_second_stu font-weight-bold"><i class="fa fa-database main_fa_stu"></i> Results</h3>
          <div class="clearfix"></div>
        </div>
        <div class="">
          <!-- Div containing the results-->
          <div id="boxResults"></div>
          <!-- /Div containing the results-->
        </div>
      </div>
    </div>
    <!-- /Results-->

    
</div>
<!-- /page content -->
