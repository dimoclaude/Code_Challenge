<?php
    /** 
        *Product filtering
    */

    /** 
        *Test to determine whether the user has selected the product to be filtered
    */
    if(!empty($product_id) AND empty($price_id))
    {
        /** 
            *Attributes initialization
        */
        $attributes = array();

        /** 
            *If the admin choses all the Customers and all the Products or no Customer and no Product then we print all the prices
        */
        if(($product_id == 'all_products' && $_POST['customer_id'] == 'all_customers') || ($product_id == 'no_product' && $_POST['customer_id'] == 'no_customer') || ($product_id == 'all_products' && $_POST['customer_id'] == 'no_customer'))
        {
            $statement = "SELECT product_price, price_id FROM prices ORDER BY product_price ASC";
        
            if($product_id == 'no_product' && $_POST['customer_id'] == 'no_customer')
            {
                /** 
                    *Results for the specific case where the user has selected the options no customer and no product
                    *These results will be shown in a table.
                */
                echo '<option value="all_products">All Prices</option>----------';
                    $th_product_name = ($product_id == 'no_product')?'':$th_product_name;
                    $colspan = ($product_id == 'no_product')?1:2;
                echo '
                    <table class="table table-striped">
                        <thead>
                            <tr>
                                <th>#</th>
                                '.$th_product_name.'
                                <th><i class="fa fa-money main_fa_stu"></i> Product Price</th>
                                <th><i class="fa fa-clock-o main_fa_stu"></i> Sale Date</th>
                            </tr>
                        </thead>
                        <tbody>
                             ';


                            $statement = "SELECT prices.price_id, product_price, 
                            product_name, sale_date
                            FROM sales 
                            LEFT JOIN prices ON sales.price_id = prices.price_id
                            LEFT JOIN products ON sales.product_id = products.product_id
                            ORDER BY sale_date DESC";

                            $idx = 1;
                            $total_price = 0;
                            foreach(App\App::getDB() -> SELECT($statement) AS $sale)
                            {
                                $td_product_name = ($product_id != 'all_products')?'<td>'.($sale -> product_name).' </td>':'';
                                echo '
                                <tr>
                                    <th scope="row">'.$idx.'</th>
                                    '.$td_product_name.'
                                    <td>'.($sale -> product_price).' €</td>
                                    <td>'.($sale -> sale_date).' </td>
                                </tr>';
                                $idx += 1;
                                $total_price += $sale -> product_price;
                            }
                            echo '
                            <tr>
                                <th scope="row" class="text-right" colspan = "'.$colspan.'">TOTAL PRICE</th>
                                <td>'.$total_price.' €</td>
                                <td> </td>
                            </tr>';
                echo '
                        </tbody>
                    </table>----------success';

            }
        } 
        else
        {
            /** 
                *Query initialization. The query can be modified according to the filtered objects
            */
            $statement = "SELECT DISTINCT prices.price_id, product_price FROM 
            prices 
            LEFT JOIN sales ON sales.price_id = prices.price_id";

            /** 
                *Attributes initialization
            */
            $attributes = array('product_id' => $product_id);
            
            if(($product_id != 'no_product' && $_POST['customer_id'] == 'no_customer') || ($product_id != 'no_product' && $_POST['customer_id'] == 'all_customers'))
            {
                /** 
                    *In the database, we select the distinct prices of the chosen product.
                */
                $statement .= " WHERE product_id = :product_id ORDER BY product_price ASC";
            }
            else if($product_id == 'all_product_customer' && $_POST['customer_id'] != 'no_customer')
            {
                /** 
                    *In the database, we select the distinct prices of all the products of the chosen customer.
                */
                $statement .= " WHERE customer_id = :customer_id ORDER BY product_price ASC";
                $attributes = array('customer_id' => $_POST['customer_id']); 
            }
            else
            {
                /** 
                    *In the database, we select the distinct prices of the chosen customer and product.
                */
                $statement .= " WHERE customer_id = :customer_id AND product_id = :product_id ORDER BY product_price ASC";
                $attributes = array('customer_id' => $_POST['customer_id'], 'product_id' => $product_id); 
            }
        }  
        
        /** 
            *When the resuest is a success we put the different in a select box.
        */
        if($product_id != 'no_product')
        {   
            echo ($_POST['customer_id'] != "")?'<option value="">Select a Price</option>':'<option value="">Waiting for the Product</option>';

            if(($product_id == 'all_products' && $_POST['customer_id'] == 'all_customers') || ($product_id == 'no_product' && $_POST['customer_id'] == 'no_customer') || ($product_id != 'no_product' && $_POST['customer_id'] == 'no_customer'))
                echo '<option value="all_prices">All Prices</option>';
            else echo ($_POST['customer_id'] != "")?'<option value="all_price_customer">All its Prices</option>':'';
            
            /** 
                *Price generation based on customer and product selection.
            */
            foreach(App\App::getDB() -> SELECT($statement, $attributes) AS $price)
                echo '<option value="'.($price -> price_id).'">'.($price -> product_price).'</option>';
        }
    }
    /** 
        *End of the product filtering
    */
?>