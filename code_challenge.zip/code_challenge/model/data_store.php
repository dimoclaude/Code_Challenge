<?php
    /**  
        *This file allows to read a JSON file with PHP and store its its data in the database book_shop
    */

    
    
    /**
     * Inclusion of files allowing to access and send resquest to the database
    */
    require("../app/Tables/Database.php");
    require("../app/Tables/App.php");
    
    /**
     * Path to the JSON file
    */
    $file = './sales.json'; 

    /**
     * Put the file contents in a PHP variable
    */
    $data = file_get_contents($file); 
    
    /**
     * Decode JSON stream
    */
    $all_sales = json_decode($data); 

    /** 
        *According to our problem statement, I was able to identify four SQL tables, namely : customers, prices, products, and sales
        *Customer, price and product tables are defined in normal form (1FN).
    */

    /** 
        *Extraction of non-redundant customer information.
    */
    $customers = array_unique(array_column($all_sales, 'customer_name', 'customer_mail'));
    
    /** 
        *Extraction of non-redundant product information.
    */
    $products = array_unique(array_column($all_sales, 'product_name', 'product_id'));

    /** 
        *Extraction of non-redundant price information.
    */
    $prices = array_unique(array_column($all_sales, 'product_price', 'sale_id'));
    
    /** 
        *Extraction of sale information.
    */
    $sales = array_column($all_sales, 'sale_date', 'sale_id');

    /** 
        *Extraction of customer IDs.
    */
    $customer_ids = array_flip(array_keys($customers));

    /** 
        *Extraction of price IDs.
    */
    $price_ids = array_flip(array_values($prices));
    
    /** 
        *Extraction of foreign keys to feed the sales table.
    */
    $keys_products = array_column($all_sales, 'product_id', 'sale_id');
    $keys_customers = array_column($all_sales, 'customer_mail', 'sale_id');
    $keys_prices = array_column($all_sales, 'product_price', 'sale_id');
    

    /** 
        *Inserting each distinct customer in the customer table.
    */
    foreach($customers AS $customer_mail => $customer_name)
    {
        $statement = "INSERT INTO customers (customer_name, customer_mail) VALUES (:customer_name, :customer_mail)";
        $attributes = array('customer_name' => $customer_name, 'customer_mail' => $customer_mail);
        App\App::getDB() -> INSERT($statement, $attributes);
    }

    /** 
        *Inserting each distinct product in the product table.
    */
    foreach($products AS $product_name)
    {
        $statement = "INSERT INTO products (product_name) VALUES (:product_name)";
        $attributes = array('product_name' => $product_name);
        App\App::getDB() -> INSERT($statement, $attributes);
    }

    /** 
        *Inserting each distinct price in the price table.
    */
    foreach($prices AS $product_price)
    {    
        $statement = "INSERT INTO prices (product_price) VALUES (:product_price)";
        $attributes = array('product_price' => $product_price);
        App\App::getDB() -> INSERT($statement, $attributes);
    }

    /** 
        *Inserting each sale in the sale table.
    */
    foreach($sales AS $sale_id => $sale_date)
    {
        $statement = "INSERT INTO sales (customer_id, product_id, price_id, sale_date) VALUES (:customer_id, :product_id, :price_id, :sale_date)";
        $attributes = array('customer_id' => $customer_ids[$keys_customers[$sale_id]] + 1, 'product_id' => $keys_products[$sale_id], 'price_id' => $price_ids[$keys_prices[$sale_id]] + 1, 'sale_date' => $sale_date);
        App\App::getDB() -> INSERT($statement, $attributes);
    }
?>