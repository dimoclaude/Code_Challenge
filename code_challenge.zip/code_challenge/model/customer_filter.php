
<?php    

    /**
     * Test to determine whether the user has selected the customer to be filtered
    */
    
    if(empty($product_id) && isset($_POST['customer_id']))
    {
        /**
         * Attributes initialization
        */
        $attributes = array();
        
        /**
         * Before sending the request to the server, we need to know if the admin has chosen all Customers, no Customer or only one of them
        */
        if($_POST['customer_id'] == "all_customers" || $_POST['customer_id'] == "no_customer")
        {
            /**
             * Then we select all the products of the database.
            */
            $statement = "SELECT product_name, product_id FROM products ORDER BY product_name ASC";
        }
        else
        {
            /**
             * In the database, we select the distinct products of the chosen customer.
             */
            $statement = "SELECT DISTINCT product_name, products.product_id FROM 
            products 
            LEFT JOIN sales ON sales.product_id = products.product_id
            WHERE customer_id = :customer_id ORDER BY product_name ASC";
            $attributes = array('customer_id' => $_POST['customer_id']); 
        }

        /**
         * When the resuest is a success we put the different prices in the corresponding list
         */
        
        echo ($_POST['customer_id'] != "")?'<option value="">Select a Product</option>':'<option value="">Waiting for the Customer</option>';
        echo ($_POST['customer_id'] == "all_customers" || $_POST['customer_id'] == "no_customer")?'<option value="all_products">All Products</option>':(($_POST['customer_id'] != "")?'<option value="all_product_customer">All its Products</option>':'');
        echo ($_POST['customer_id'] == "no_customer")?'<option value="no_product">No Product</option>':'';
        
        foreach(App\App::getDB() -> SELECT($statement, $attributes) AS $product)
        {
            echo '<option value="'.($product -> product_id).'">'.($product -> product_name).'</option>';
        }   
    }

    /**
     * End of the customer filtering
     */

?>