<?php 
    /** 
        *This class allows to access the project database by means of the Database class.
        *This class is static so that we don't need any instantiation to call it.
    */
    /** 
        *Namespace of the class.
    */
    namespace App;
    
    class App{
        
        /** 
            *Initialization of the required parameters to access the database. As defined, those parameters can only be defined here.
            *so that it becomes more easy to change the connection paramaters without updating any other file of the project  
        */
        const DB_HOST = 'localhost';
        const DB_NAME = 'book_shop';
        const DB_USER = 'root';
        const DB_PASS = '';

        /** 
            *Variable in which the connexion will be stored. Such a parameter is used only in this class, explaining why 
            *it is defined as a private variable   
        */
        private static $database;

        /** 
            *Public method allowing to be connected to the database. it is public function, since it will be used out of the class  
        */
        public static function getDB()
        {
            if(self::$database === null)
                self::$database = new Database(self::DB_HOST, self::DB_NAME, self::DB_USER, self::DB_PASS);
            return self::$database;
        }
    }

?>