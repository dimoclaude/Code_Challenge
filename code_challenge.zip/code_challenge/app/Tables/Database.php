<?php
    /** 
        *In addition to access the database, this class contains methods allowing to prepare and send requests to the server.
    */

    /** 
        *Namespace of the class.
    */
    namespace App;

    /** 
        *use of \PDO. This allows to use the PDO methods while being in the namespace App
    */
    use \PDO;

    class Database{

        /** 
            *Variables that content the parameters allowing to access the database
        */
        private $db_host;
        private $db_name;
        private $db_user;
        private $db_pass;

        private $database;

        /** 
            *The constructor allows to define a new instance of the class by passing properties in parameter 
        */
        public function __construct($db_host = 'localhost', $db_name, $db_user = 'root', $db_pass = ''){
        
            $this -> db_host = $db_host;
            $this -> db_name = $db_name;
            $this -> db_user = $db_user;
            $this -> db_pass = $db_pass;
        }

        /** 
            *The below method allows to define the connexion to the database. It is defined in the class, since we don't need
            *to used it out of the class
        */
        private function getDB()
        {
            if($this -> database === null)
            {
                $database = new PDO('mysql:host='.($this -> db_host).'; dbname='.($this -> db_name), $this -> db_user, $this -> db_pass, array(PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION, PDO::MYSQL_ATTR_INIT_COMMAND => "SET NAMES utf8"));
                $this -> database = $database;
            }            
            return $this -> database;
        }

        /** 
            *Method allowing to select data in a given table of the database 
        */
        public function SELECT($statement, $attributes = "")
        {            
            if(empty($attributes))
            {
                /** 
                    *Connexion to the database 
                */
                $query = $this -> getDB(); 

                /** 
                    *Use the query mothod of PDO to execute the statement when there is no attribute. 
                    *fetchall(PDO::FETCH_OBJ) allows to find all the results in object array
                */
                return $query ->  query($statement) -> fetchall(PDO::FETCH_OBJ);
            }
            else 
            {
                /** 
                    *$this -> getDB(): Connexion to the database 
                    *-> prepare($statement): In a presence of attributes, we to prepare the query in order to secure data
                */
                $query = $this -> getDB() -> prepare($statement);

                /** 
                    *Statement execution
                */
                $query -> execute($attributes);
                
                /** 
                    *Return all the results in an object array
                */
                return $query_data = $query -> fetchall(PDO::FETCH_OBJ);
            }
        }


        /** 
            *Method allowing to insert data in a given table of the database 
        */
        public function INSERT($statement, $attributes = array())
        {
            /** 
                *Connexion to the database 
            */
            $query = $this -> getDB(); 

            /** 
                *In the absence of attribute we directly execute the statement
                *In the presence of attributes we prepare and execute the statement so that we preserve the data security 
            */
            if(empty($attributes))
                return $query ->  query($statement);
            else 
            {
                return $query -> prepare($statement) -> execute($attributes);
            }
        }

    }


?>