<?php
    class Filter{

        /** 
            *Initialization of the class properties. 
            *They are all defined in private, sothat we define setters in order to access them out of the class
        */
        private $list_length = 3;
        private $list_title = "Select a";
        private $onchange_event = "getProducts(this.value)";
        
        /** 
            *Method allowing to access the length of the list. 
        */
        public function getOptionLength($list_length)
        {
            return $this -> list_length = $list_length;
        }

        /** 
            *Method allowing to access the title of the list. 
        */
        public function getOptionTitle($list_title)
        {
            return $this -> list_title = $list_title;
        }

        /** 
            *Method allowing to access the html even associated to corresponding list. 
        */
        public function getOnChangeEvent($onchange_event)
        {
            return $this -> onchange_event = $onchange_event;
        }

        
        /** 
            *Method allowing to create select lists in order to manage filters. 
        */
        public function select($data, $name)
        {

            $selectform = '
            <div class="col-md-'.($this -> list_length).' col-sm-'.($this -> list_length).' ">
                <select class="form-control" name="'.$name.'" id="'.$name.'" onchange="'.($this -> onchange_event).'">
                <option value="">'.($this -> list_title).' '.ucfirst($name).'</option>';

                if(!empty($data))
                {
                    foreach($data AS $index => $val)
                        $selectform .= '<option value="'.$index.'">'.$val.'</option>';
                }
            $selectform .= '
                </select> 
                <div> '.ucfirst($name).' <span class="required">*</span></div>
            </div>
            ';

            return $selectform;
        }
        
    }

?>